@echo off
chcp 65001 >nul
title VocabTool Setup

set "INSTALL_DIR=%USERPROFILE%\VocabTool"
set "SHORTCUT=%USERPROFILE%\Desktop\VocabTool.lnk"

REM === Uninstall mode ===
if /i "%1"=="uninstall" goto :uninstall

REM === Install mode ===
echo =====================================
echo   VocabTool Setup / Upgrade
echo =====================================
echo.
echo Install path: %INSTALL_DIR%

REM Auto-cleanup: if directory exists, remove old files first
if exist "%INSTALL_DIR%" (
    echo.
    echo [*] Old installation detected, cleaning up...
    for /d %%i in ("%INSTALL_DIR%\*") do rmdir /s /q "%%i" 2>nul
    for %%i in ("%INSTALL_DIR%\*") do del /q "%%i" 2>nul
    echo  [OK] Old files removed
)
echo.

set /p CONFIRM="Continue? (Y/N): "
if /i not "%CONFIRM%"=="Y" (
    echo Setup cancelled.
    pause
    exit /b
)

echo.
echo Copying files...

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%INSTALL_DIR%\bin" mkdir "%INSTALL_DIR%\bin"

xcopy /E /I /Y "%~dp0*" "%INSTALL_DIR%\" >nul
echo  [OK] Files copied to %INSTALL_DIR%

echo  [OK] Creating desktop shortcut...

REM Force recreate shortcut to ensure icon is updated
if exist "%SHORTCUT%" del /q "%SHORTCUT%" 2>nul
powershell -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%SHORTCUT%');$s.TargetPath='wscript.exe';$s.Arguments='\"%INSTALL_DIR%\launcher.vbs\"';$s.WorkingDirectory='%INSTALL_DIR%';$s.Description='VocabTool - English Vocabulary Generator';$s.IconLocation='%INSTALL_DIR%\app.ico,0';$s.Save()" >nul 2>&1
if exist "%SHORTCUT%" (
    echo  [OK] Desktop shortcut created
) else (
    echo  [!] Could not create desktop shortcut
    echo      You can manually create one for: launcher.vbs
)

echo  [OK] Setting folder icon...
REM Create desktop.ini for folder icon
set "INI_FILE=%INSTALL_DIR%\desktop.ini"
(
    echo [.ShellClassInfo]
    echo IconResource=%INSTALL_DIR%\app.ico,0
    echo IconFile=%INSTALL_DIR%\app.ico
    echo IconIndex=0
) > "%INI_FILE%"
attrib +s +h "%INI_FILE%" >nul 2>&1
attrib +r "%INSTALL_DIR%" >nul 2>&1

echo  [OK] Refreshing icon cache...
REM Touch the ico file timestamp to trigger icon cache refresh
copy /b "%INSTALL_DIR%\app.ico"+,, "%INSTALL_DIR%\app.ico" >nul 2>&1
REM Notify shell to reload icons
powershell -Command "(New-Object -ComObject Shell.Application).Windows() | ForEach-Object { try { $_.Refresh() } catch {} }" >nul 2>&1

echo.
echo =====================================
echo   Setup Complete!
echo =====================================
echo.
echo How to use:
echo   1. Double-click "VocabTool" on desktop
echo   2. First run auto-downloads Node.js (~25MB)
echo   3. Browser opens automatically
echo.
echo Close browser tab to stop the server.
echo.
pause
exit /b

REM === Uninstall ===
:uninstall
echo =====================================
echo   VocabTool Uninstall
echo =====================================
echo.

if not exist "%INSTALL_DIR%" (
    echo VocabTool is not installed.
    pause
    exit /b
)

echo This will remove:
echo   - %INSTALL_DIR%
echo   - Desktop shortcut
echo.
set /p CONFIRM="Uninstall? (Y/N): "
if /i not "%CONFIRM%"=="Y" (
    echo Uninstall cancelled.
    pause
    exit /b
)

echo.
echo Removing files...

REM Remove read-only attribute for clean deletion
if exist "%INSTALL_DIR%" (
    attrib -r "%INSTALL_DIR%" 2>nul
    if exist "%INSTALL_DIR%\desktop.ini" (
        attrib -s -h "%INSTALL_DIR%\desktop.ini" 2>nul
    )
    rmdir /s /q "%INSTALL_DIR%" 2>nul
    echo  [OK] Program files removed
)

echo Removing desktop shortcut...
if exist "%SHORTCUT%" (
    del /q "%SHORTCUT%" 2>nul
    echo  [OK] Desktop shortcut removed
)

echo.
echo =====================================
echo   Uninstall Complete!
echo =====================================
echo.
pause
exit /b
