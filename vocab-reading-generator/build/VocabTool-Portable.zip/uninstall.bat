@echo off
start /wait "" "%~dp0setup.bat" uninstall
