VocabTool - 考研英语背词助手
===============================

一、使用说明

1. 双击 launcher.vbs 启动程序
   - 会自动打开浏览器显示主界面
   - 不会显示黑色的控制台窗口

2. 关闭方式
   - 直接关闭浏览器页面或标签页
   - 服务器会在5秒后自动停止
   - 也可以按 Ctrl+C（如果在控制台运行）

3. 调试模式
   如果需要查看服务器日志，在命令行执行：
   VocabTool.exe --debug

二、目录结构

VocabTool/
├── VocabTool.exe         ← 主程序（双击不会显示窗口）
├── launcher.vbs          ← 启动器（推荐双击这个）
├── index.html            ← 主页面
├── assets/               ← 图标资源
├── css/                  ← 样式文件
├── js/                   ← JavaScript
├── vocab-lib/            ← 内置词库
├── data/                 ← 用户数据（自动创建）
└── README.txt            ← 本文件

三、数据备份

所有数据存储在浏览器的 localStorage 中。
建议定期导出重要数据。
